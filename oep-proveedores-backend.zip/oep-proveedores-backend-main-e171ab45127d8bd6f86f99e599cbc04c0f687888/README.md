# Sistema de logistica electoral

<img src="https://upload.wikimedia.org/wikipedia/commons/7/72/Logo_oep.png" alt="Octopus" width="150px" height="150px"> 
<br>

# Author

<strong>Ing. Jose Lenin Aparicio Loayza</strong>

#Contact

Mobile: <img src="https://flagicons.lipis.dev/flags/4x3/bo.svg" width="32px" height="16px;"> +(591)-76108443 <br />
Email: ts.ceo.t1000@gmail.com

#Git

git config credential.helper store <br>
git config --global init.defaultBranch main <br>
============================================ <br>
git init <br>
git symbolic-ref HEAD refs/heads/main <br>

#Queue work

```nohup php artisan queue:work --daemon &```
<br>
``php artisan queue:work``

# Second remote

git remote set-url --add --push origin git://another/repo.git
